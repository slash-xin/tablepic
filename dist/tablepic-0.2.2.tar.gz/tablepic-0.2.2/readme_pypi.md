<!--
 * @Author: xinyan
 * @Date: 2023-06-16 15:32:25
 * @LastEditors: xinyan
 * @LastEditTime: 2023-06-16 15:33:40
 * @Description: file content
-->
# TablePic
## Overview
This package uses PIL (pillow) to generate a picture that contains a table. It has similar functionality to matplotlib's table, but includes more customization options.

## Instruction

The instruction of the package, see: [tablepic](https://github.com/slash-xin/tablepic)

# LICENSE

Please refer to [LICENSE](LICENSE) file.