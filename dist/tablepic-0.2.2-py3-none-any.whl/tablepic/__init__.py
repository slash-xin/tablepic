'''
Author: xinyan
Date: 2023-06-13 17:12:19
LastEditors: xinyan
LastEditTime: 2024-03-07 16:50:45
Description: file content
'''


from .main import generate_table_pic, combine_multiple_pic, complex_table_pic