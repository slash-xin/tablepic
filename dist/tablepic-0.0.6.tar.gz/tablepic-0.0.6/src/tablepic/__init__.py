'''
Author: xinyan
Date: 2023-06-13 17:12:19
LastEditors: xinyan
LastEditTime: 2023-06-14 23:44:10
Description: file content
'''


from .main import generate_table_pic